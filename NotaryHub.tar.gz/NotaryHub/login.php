<?php

$error=''; // Variable To Store Error Message
if(isset($_POST['submit'])) {
	if (empty($_POST['uname']) || empty($_POST['psw'])) {
$error = "Username or Password is invalid";
}
else
{
   include("connectdb.php");
	session_start(); // Starting Session
// Define $username and $password
$username=$_POST['uname'];
$password=$_POST['psw'];
// Establishing Connection with Server by passing server_name, user_id and password as a parameter

// To protect MySQL injection for Security purpose
//$username = stripslashes($username);
//$password = stripslashes($password);
//$username = $username->real_escape_string;
//$password = $password->real_escape_string;
// Selecting Database
// SQL query to fetch information of registerd users and finds user match.
$sql ="SELECT username FROM userdata WHERE (username='$username' OR email='$username') AND password='$password'";
$result=$conn->query($sql);
if ($result->num_rows > 0) {
	
	while($row=$result->fetch_assoc()){
		$user= $row["username"];
	}
$_SESSION['login_user']=$user;
$_SESSION['loggedin_time']=time();// Initializing Session
header("location:DashBoard.php"); // Redirecting To Other Page
} else {
 echo "<script type='text/javascript'> alert('username or password Invalid ') </script>";
}

}
}
?>